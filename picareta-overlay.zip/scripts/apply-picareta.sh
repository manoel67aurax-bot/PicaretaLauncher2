#!/usr/bin/env bash
# Liga os módulos do Picareta no projeto Zalith Launcher 2+. Pode rodar quantas vezes quiser (idempotente).
set -euo pipefail
cd "$(dirname "$0")/.."
APP="${APP_MODULE:-ZalithLauncher}"

[ -f settings.gradle.kts ] || { echo "Rode na raiz do ZalithLauncher2Plus"; exit 1; }

grep -q '":picareta-core"' settings.gradle.kts || printf '\ninclude(":picareta-core", ":picareta-ui")\n' >> settings.gradle.kts

if ! grep -q 'project(":picareta-ui")' "$APP/build.gradle.kts"; then
  sed -i '0,/^dependencies {/s//dependencies {\n    implementation(project(":picareta-ui"))/' "$APP/build.gradle.kts"
fi

# Pacote diferente do oficial: dá pra instalar junto com o Zalith original sem conflito
sed -i 's/applicationIdSuffix = ".v2"/applicationIdSuffix = ".picareta"/' "$APP/build.gradle.kts"

# Nome do app (licença do ZL2 proíbe usar "ZalithLauncher"/"ZL" em versões modificadas)
if [ -f gradle.properties ]; then
  sed -i 's/^launcher_app_name=.*/launcher_app_name=Picareta Launcher (Unofficial)/' gradle.properties
  sed -i 's/^launcher_name=.*/launcher_name=PicaretaLauncher/' gradle.properties
  sed -i 's/^launcher_short_name=.*/launcher_short_name=Picareta/' gradle.properties
fi

echo "Picareta aplicado em $APP ✔"
grep -n 'picareta' settings.gradle.kts "$APP/build.gradle.kts" || true
