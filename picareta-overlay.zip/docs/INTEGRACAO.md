# Integração fase 2 (dentro do app principal)

Na fase 1 o Picareta roda como **hub separado** (segundo ícone) e já funciona sem mexer no código do Zalith 2+.
A fase 2 coloca tudo na navegação principal. Pontos de encaixe (nomes podem variar por versão do fork; procure
pelos termos no Android Studio ou na busca do GitHub):

1. **Navegação**: o app usa Navigation 3. Adicione destinos chamando `ProfileScreen`, `ContentBrowserScreen`,
   `ConfigScreen` e `EditionPicker`. Depois remova o `intent-filter` LAUNCHER do `picareta-ui/AndroidManifest.xml`.
2. **Contas**: troque `AccountStore` pelo gerenciador de contas do Zalith (busque `Account` / `AccountsManager`).
   Converta `Account.Offline/ElyBy` pro modelo deles. O backup do Zalith 2+ continua valendo; o do Picareta é extra.
3. **Ely.by no jogo**: na montagem dos argumentos da JVM (busque `javaagent` ou `authlib`), se a conta for Ely.by,
   adicione `ElyByAuth.javaAgentArg(caminhoDoAuthlibInjector)`. Baixe o `authlib-injector.jar` das releases
   oficiais (github.com/yushijinhun/authlib-injector) e coloque em `assets/`.
4. **Controles Bedrock**: implemente `GameInput` com a ponte de input do Pojav (busque `CallbackBridge`:
   `sendKeycode`, `sendMouseButton`, `mouseX/mouseY`) e mostre `BedrockControls` quando
   `settings.controls == ControlStyle.BEDROCK`.
5. **Pasta do jogo**: o hub usa `getExternalFilesDir(null)/.minecraft`. Se o Zalith usar outra pasta/instância,
   passe a pasta certa pro `ContentInstaller`.
6. **Modpacks**: `InstallResult.NeedsModpackInstaller` → chame o importador de `.mrpack`/CurseForge que o Zalith já tem.
7. **Renderizador/RAM/FPS**: mapeie `PicaretaSettings` pras chaves de config do Zalith (busque `renderer`, `ram`,
   `resolution`) ou use só os presets como atalho que grava nas chaves deles.
