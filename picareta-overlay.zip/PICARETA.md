# Picareta Launcher ⛏️ (não oficial)

Launcher de **Minecraft: Java Edition para Android**, montado em cima do **Zalith Launcher 2+**
(fork do Zalith Launcher 2 → motor PojavLauncher, UI Jetpack Compose + Material 3).

O Picareta **não reinventa o motor do jogo**: o Java Edition precisa de JVM, LWJGL e renderizadores
(MobileGlues/Zink/GL4ES) já portados pro Android, e isso o Zalith 2+ já faz bem. A gente adiciona por cima
um **núcleo em Rust** e telas novas.

## O que vem do Zalith 2+ (mantido)
- Motor de launch (Java 8/17/21/25), Fabric/Forge/NeoForge/Quilt/OptiFine, todas as versões release/snapshot
- Login Microsoft, **contas offline**, **sistema de capas**, **nomes chroma**
- **Atalhos na tela inicial**, **importar/exportar config e contas (com skins, capas e chroma)**
- MobileGlues com config, **config UI remake**, correções e melhorias de desempenho

## O que o Picareta adiciona
| Recurso | Onde |
|---|---|
| Núcleo **Rust** (UUID offline, validação de skin/capa, detecção de arquivo, SHA-1, backup zip seguro) | `picareta-core/rust` |
| Conta **Ely.by** (login, 2FA, refresh, skins no jogo via authlib-injector) | `core/auth/ElyByAuth.kt` |
| Aba **Perfil**: conta ativa, **botão Skin**, **botão Capa**, modelo slim, **criar conta** (Microsoft/Ely.by no site oficial), offline | `ui/ProfileScreen.kt` |
| Aba **Baixar**: Modrinth + CurseForge, mods, modpacks, texturas, shaders, datapacks, mundos, com checagem SHA-1 | `ui/ContentBrowserScreen.kt` |
| Instalação automática: descobre se o arquivo é mod/textura/shader/mundo/modpack/pack Bedrock e põe na pasta certa | `core/content/ContentInstaller.kt` |
| **Bedrock**: abre o app oficial e importa `.mcpack/.mcaddon/.mcworld` direto nele | `core/bedrock/BedrockBridge.kt` |
| **Controles estilo Bedrock** (analógico, arrastar pra olhar, segurar pra quebrar, toque pra usar) | `ui/BedrockControls.kt` |
| **Config** com presets (Bateria/Equilíbrio/Desempenho), busca e limite de RAM pelo aparelho | `ui/ConfigScreen.kt` |
| Backup `.zip` **sem senhas/tokens** (proteção contra zip-slip e zip bomb) | `rust/src/backup.rs` |
| Aba **Jogar**: Java · Bedrock · Java+Bedrock juntos (Geyser) | `ui/EditionPicker.kt` |

## Papo reto: o que NÃO dá (e o que fazemos no lugar)
| Pedido | Realidade | O que o Picareta faz |
|---|---|---|
| Instalar/rodar **Bedrock** dentro do launcher | Bedrock é um app nativo pago, separado. Nenhum launcher legítimo roda ele por dentro | Abre o app oficial, importa packs/addons/mundos nele |
| "Misturar" Java e Bedrock | Não existe cliente híbrido | Servidor Java com **Geyser + Floodgate**: Bedrock entra no mundo Java |
| Shader do Bedrock no Java (e vice-versa) | Formatos incompatíveis (RenderDragon x GLSL/Iris) | Java: Iris/OptiFine + MobileGlues. Bedrock: Vibrant Visuals/packs no app oficial |
| Launcher **100% em Rust** | O jogo Java exige JVM; UI nativa Android em Rust é pior que Compose | Rust no núcleo pesado de arquivos, Kotlin/Compose na UI |
| Login Microsoft "de fábrica" | Desde 2022 a Mojang exige **Client ID do Azure aprovado** (senão HTTP 403) | Usa o fluxo do Zalith com seu `OAUTH_CLIENT_ID` |
| CurseForge sem chave | API exige `x-api-key` | Secret `CURSEFORGE_API_KEY`; arquivos bloqueados abrem no site |

Conta offline é pra singleplayer e servidores em offline-mode. Pra jogar de verdade, tenha o jogo original.

---

## 📱 Como gerar o APK usando só o celular

Você não precisa de PC: o **GitHub Actions** compila na nuvem.

1. **Crie conta no GitHub** (github.com, no navegador do celular, ative "Versão para computador").
2. Abra `github.com/Star1xr/ZalithLauncher2Plus` e toque em **Fork** → *Create fork*.
3. No seu fork: **Add file → Upload files** → envie o **`picareta-overlay.zip`** (um arquivo só, sem descompactar) → *Commit changes*.
4. **Add file → Create new file**, nome: `.github/workflows/picareta-build.yml`, cole o conteúdo do arquivo de mesmo nome que veio no zip → *Commit*.
5. (Opcional, recomendado) **Settings → Secrets and variables → Actions → New repository secret**:
   - `CURSEFORGE_API_KEY`: chave gratuita em console.curseforge.com (sem ela, só a aba Modrinth funciona)
   - `OAUTH_CLIENT_ID`: Client ID do Azure aprovado pela Mojang (sem ele, use offline/Ely.by)
6. **Actions → Picareta APK → Run workflow** → `arm64` + `Debug` → *Run*. Leva uns 20–40 min.
7. Quando ficar verde ✅, abra a execução → **Artifacts** → baixe `picareta-Debug-arm64` (vem em .zip).
8. Extraia o zip (app Arquivos), toque no `.apk`, permita **"Instalar apps desconhecidos"** e instale.

> Plano B (avançado, Termux): `pkg install git` → `git clone` do seu fork → `unzip picareta-overlay.zip` →
> `git add . && git commit -m picareta && git push`. Compilar Android direto no Termux é instável; use o Actions.

Release: troque `Debug` por `Release`. Sai assinado com a chave do projeto (ok pra uso pessoal);
pra distribuir, gere sua própria keystore.

## ✅ Como testar (checklist)
1. Abra **Picareta Launcher (Unofficial)** → instale **1.20.1 vanilla** → jogue com **MobileGlues**. Abriu = motor ok.
2. Abra o ícone **Picareta** (hub) → **Perfil** → *Adicionar conta → Offline* → nome `Teste_123`.
3. **Botão Skin** → escolha um PNG 64×64. PNG errado precisa mostrar erro (validação do Rust).
4. **Baixar → Modrinth → Mods** → busque `mod menu` → Instalar. Confira em `.minecraft/mods`.
5. **Shaders** → instale um (ex.: Complementary) numa instância **Fabric + Iris** e teste com MobileGlues.
6. **Mundos/Texturas** → instale um e veja se aparece no jogo.
7. **Jogar → Bedrock**: com o app oficial instalado, baixe/importe um `.mcpack` e veja o Bedrock abrir importando.
8. **Config** → toque nos presets e veja RAM/resolução/FPS mudarem; **Exportar tudo** → apague a conta → **Importar** → conta volta com skin.
9. Mantenha o celular na tomada e com ventilação no primeiro teste longo.

**Logs quando algo quebrar:** no Zalith, *Configurações → Logs* (latestlog). Ou via **Depuração por Wi-Fi** +
app **LADB**: `logcat | grep -i -E "picareta|pojav|zalith"`. A aba **Actions** mostra o erro exato de build.

## Estrutura
```
picareta-core/   Android library: Kotlin + Rust (cargo-ndk → libpicareta_core.so)
  rust/src/      offline.rs · skin.rs · detect.rs · backup.rs · lib.rs (JNI)   [com testes]
picareta-ui/     Telas Compose: Perfil, Baixar, Config, Edições, Controles Bedrock, Hub
scripts/apply-picareta.sh   liga os módulos no Zalith 2+ (o workflow já roda)
.github/workflows/picareta-build.yml (cópia em docs/)
docs/INTEGRACAO.md          fase 2: ligar tudo dentro da tela principal do Zalith
```

Licença: GPL-3.0 (herdada). Não afiliado a Mojang, Microsoft, Zalith Launcher, Modrinth, CurseForge ou Ely.by.
