package app.picareta.ui

import android.view.HapticFeedbackConstants
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Para ligar no motor do Pojav/Zalith: implemente com CallbackBridge (sendKeycode / sendMouseButton / mouse delta).
 * Códigos são GLFW (W=87, A=65, S=83, D=68, SPACE=32, LSHIFT=340, E=69, T=84, ESC=256).
 */
interface GameInput {
    fun key(glfwKey: Int, down: Boolean)
    fun mouseButton(button: Int, down: Boolean) // 0 = esquerdo (quebrar), 1 = direito (usar)
    fun look(dx: Float, dy: Float)
}

private object K { const val W = 87; const val A = 65; const val S = 83; const val D = 68; const val SPACE = 32; const val SHIFT = 340; const val E = 69; const val T = 84; const val ESC = 256 }

/**
 * Controles estilo Bedrock: analógico à esquerda, câmera arrastando no lado direito,
 * toque curto = usar/colocar, segurar = quebrar (igual Bedrock), botões de pular/agachar.
 */
@Composable
fun BedrockControls(input: GameInput, opacity: Float, haptics: Boolean, modifier: Modifier = Modifier) {
    val view = LocalView.current
    fun buzz() { if (haptics) view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
    var sneaking by remember { mutableStateOf(false) }

    Box(modifier.fillMaxSize()) {
        // Câmera + quebrar/usar: metade direita inteira
        Box(Modifier.fillMaxHeight().fillMaxWidth(0.55f).align(Alignment.CenterEnd)
            .pointerInput(Unit) { detectDragGestures { c, d -> c.consume(); input.look(d.x, d.y) } }
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { input.mouseButton(1, true); input.mouseButton(1, false) },
                    onLongPress = { buzz(); input.mouseButton(0, true) },
                    onPress = { tryAwaitRelease(); input.mouseButton(0, false) },
                )
            })

        Joystick(Modifier.align(Alignment.BottomStart).padding(28.dp).alpha(opacity), input)

        Column(Modifier.align(Alignment.BottomEnd).padding(24.dp).alpha(opacity), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            HoldButton("⤒", 72) { down -> if (down) buzz(); input.key(K.SPACE, down) }
            HoldButton(if (sneaking) "●" else "◐", 56) { down -> if (down) { buzz(); sneaking = !sneaking; input.key(K.SHIFT, sneaking) } }
        }
        Row(Modifier.align(Alignment.TopEnd).padding(16.dp).alpha(opacity), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HoldButton("💬", 44) { if (it) input.key(K.T, true) else input.key(K.T, false) }
            HoldButton("⏸", 44) { input.key(K.ESC, it) }
        }
        HoldButton("⋯", 52, Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp).alpha(opacity)) { input.key(K.E, it) } // inventário
    }
}

@Composable
private fun Joystick(modifier: Modifier, input: GameInput) {
    val radius = 64f
    var knob by remember { mutableStateOf(Offset.Zero) }
    val pressed = remember { mutableSetOf<Int>() }
    val density = androidx.compose.ui.platform.LocalDensity.current
    val rPx = with(density) { radius.dp.toPx() }

    fun apply(o: Offset) {
        val dead = rPx * 0.25f
        val want = buildSet {
            if (o.y < -dead) add(K.W); if (o.y > dead) add(K.S)
            if (o.x < -dead) add(K.A); if (o.x > dead) add(K.D)
        }
        (pressed - want).forEach { input.key(it, false) }
        (want - pressed).forEach { input.key(it, true) }
        pressed.clear(); pressed.addAll(want)
    }

    Box(modifier.size((radius * 2).dp).background(Color.Black.copy(0.25f), CircleShape).border(2.dp, Color.White.copy(0.5f), CircleShape)
        .pointerInput(Unit) {
            detectDragGestures(
                onDragEnd = { knob = Offset.Zero; apply(Offset.Zero) },
                onDragCancel = { knob = Offset.Zero; apply(Offset.Zero) },
            ) { c, d ->
                c.consume()
                val n = knob + d
                val len = hypot(n.x, n.y)
                knob = if (len > rPx) n * (rPx / len) else n
                apply(knob)
            }
        }, contentAlignment = Alignment.Center) {
        Box(Modifier.offset { IntOffset(knob.x.roundToInt(), knob.y.roundToInt()) }.size(52.dp).background(Color.White.copy(0.8f), CircleShape))
    }
}

@Composable
private fun HoldButton(label: String, sizeDp: Int, modifier: Modifier = Modifier, onState: (Boolean) -> Unit) {
    Box(modifier.size(sizeDp.dp).background(Color.Black.copy(0.35f), RoundedCornerShape(30)).border(2.dp, Color.White.copy(0.55f), RoundedCornerShape(30))
        .pointerInput(Unit) { detectTapGestures(onPress = { onState(true); tryAwaitRelease(); onState(false) }) },
        contentAlignment = Alignment.Center) { Text(label, color = Color.White) }
}
