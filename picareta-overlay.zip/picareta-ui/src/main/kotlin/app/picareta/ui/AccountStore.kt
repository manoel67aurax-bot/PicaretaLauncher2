package app.picareta.ui

import android.content.Context
import app.picareta.core.PicaretaJson
import app.picareta.core.auth.Account
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.builtins.ListSerializer
import java.io.File

/** Contas do hub em arquivo privado do app (o Android já criptografa o armazenamento do app em repouso). */
class AccountStore(ctx: Context) {
    private val file = File(ctx.filesDir, "picareta_accounts.json")
    private val ser = ListSerializer(Account.serializer())
    private val _accounts = MutableStateFlow(load())
    val accounts = _accounts.asStateFlow()
    private val prefs = ctx.getSharedPreferences("picareta_accounts", Context.MODE_PRIVATE)
    val active = MutableStateFlow(prefs.getString("active", null))

    private fun load(): List<Account> = runCatching { PicaretaJson.decodeFromString(ser, file.readText()) }.getOrDefault(emptyList())

    private fun save(list: List<Account>) {
        _accounts.value = list
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeText(PicaretaJson.encodeToString(ser, list)); tmp.renameTo(file)
    }

    fun upsert(a: Account) { save(_accounts.value.filterNot { it.uuid == a.uuid } + a); if (active.value == null) select(a) }
    fun remove(a: Account) { save(_accounts.value.filterNot { it.uuid == a.uuid }); if (active.value == a.uuid) select(_accounts.value.firstOrNull()) }
    fun select(a: Account?) { active.value = a?.uuid; prefs.edit().putString("active", a?.uuid).apply() }
    fun replaceAll(list: List<Account>) = save(list)
}
