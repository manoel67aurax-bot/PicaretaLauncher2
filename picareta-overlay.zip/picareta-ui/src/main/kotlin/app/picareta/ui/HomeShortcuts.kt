package app.picareta.ui

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/** Fixa uma instância na tela inicial do Android. O launcher lê "picareta.instance" no Intent e já abre o jogo. */
object HomeShortcuts {
    fun pin(ctx: Context, instanceId: String, label: String, iconRes: Int, launchActivity: Class<*>): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) return false
        val intent = Intent(ctx, launchActivity).setAction(Intent.ACTION_VIEW).putExtra("picareta.instance", instanceId)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val info = ShortcutInfoCompat.Builder(ctx, "instance-$instanceId").setShortLabel(label.take(24))
            .setIcon(IconCompat.createWithResource(ctx, iconRes)).setIntent(intent).build()
        return ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    }
}
