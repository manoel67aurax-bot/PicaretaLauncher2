package app.picareta.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import app.picareta.core.ImageCheck
import app.picareta.core.PicaretaNative
import app.picareta.core.auth.Account
import app.picareta.core.auth.ElyByAuth
import app.picareta.core.auth.SkinRef
import app.picareta.core.backup.BackupManager
import app.picareta.core.content.ContentInstaller
import app.picareta.core.content.InstallResult
import app.picareta.core.nativeCall
import app.picareta.core.net.Http
import app.picareta.core.settings.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Hub do Picareta: Jogar · Perfil · Baixar · Config. Usa o tema Material You do sistema (mesmo visual do Zalith 2+). */
class PicaretaHubActivity : ComponentActivity() {
    private lateinit var settings: SettingsRepository
    private lateinit var accounts: AccountStore
    private val gameDir by lazy { File(getExternalFilesDir(null), ".minecraft") }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        Http.init(cacheDir)
        settings = SettingsRepository(this)
        accounts = AccountStore(this)
        setContent { HubTheme { Hub() } }
    }

    /** Abre a tela principal do Zalith 2+ (a outra activity LAUNCHER do mesmo APK). */
    private fun openMainLauncher() {
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(packageName)
        val target = packageManager.queryIntentActivities(main, 0).firstOrNull { it.activityInfo.name != javaClass.name } ?: return
        startActivity(Intent(main).setClassName(packageName, target.activityInfo.name))
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    /** Copia a imagem escolhida pra dentro do app, valida no Rust e salva na conta. */
    private fun saveImage(acc: Account, uri: Uri, cape: Boolean, slim: Boolean) = lifecycleScope.launch {
        val dest = File(filesDir, "${if (cape) "capes" else "skins"}/${acc.uuid}.png").apply { parentFile?.mkdirs() }
        val tmp = File(cacheDir, "pick.png")
        withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { i.copyTo(it) } } }
        val check: ImageCheck = nativeCall(if (cape) PicaretaNative.checkCape(tmp.path) else PicaretaNative.checkSkin(tmp.path))
        if (!check.ok) { toast(check.message); return@launch }
        tmp.copyTo(dest, overwrite = true)
        val skin = SkinRef(dest.path, slim)
        accounts.upsert(when (acc) {
            is Account.Offline -> if (cape) acc.copy(cape = dest.path) else acc.copy(skin = skin)
            is Account.ElyBy -> if (cape) acc.copy(cape = dest.path) else acc.copy(skin = skin)
            is Account.Microsoft -> if (cape) acc.copy(cape = dest.path) else acc.copy(skin = skin)
        })
        toast(check.message)
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun Hub() {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        val accs by accounts.accounts.collectAsStateWithLifecycle()
        val active by accounts.active.collectAsStateWithLifecycle()
        val ctx = LocalContext.current
        val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            lifecycleScope.launch {
                runCatching {
                    val tmp = File(cacheDir, "backup.picareta")
                    BackupManager.export(tmp, settings.state.value, accs)
                    withContext(Dispatchers.IO) { contentResolver.openOutputStream(uri)?.use { o -> tmp.inputStream().use { it.copyTo(o) } } }
                }.onSuccess { toast("Backup salvo (sem senhas/tokens)") }.onFailure { toast(it.message ?: "Erro") }
            }
        }
        val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri ?: return@rememberLauncherForActivityResult
            lifecycleScope.launch {
                runCatching {
                    val zip = File(cacheDir, "import.picareta")
                    withContext(Dispatchers.IO) { contentResolver.openInputStream(uri)?.use { i -> zip.outputStream().use { i.copyTo(it) } } }
                    val data = BackupManager.import(zip, File(filesDir, "imported"))
                    settings.update { data.settings }
                    accounts.replaceAll(data.accounts)
                }.onSuccess { toast("Importado! Contas Microsoft/Ely.by pedem login de novo") }.onFailure { toast(it.message ?: "Erro") }
            }
        }
        val installer = remember { ContentInstaller(this, gameDir) }

        Scaffold(
            topBar = { CenterAlignedTopAppBar(title = { Text(listOf("Jogar", "Perfil", "Baixar", "Config")[tab]) }) },
            bottomBar = {
                NavigationBar {
                    listOf(Icons.Outlined.SportsEsports to "Jogar", Icons.Outlined.Person to "Perfil", Icons.Outlined.Download to "Baixar", Icons.Outlined.Tune to "Config")
                        .forEachIndexed { i, (icon, label) ->
                            NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icon, label) }, label = { Text(label) })
                        }
                }
            },
        ) { pad ->
            androidx.compose.foundation.layout.Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> EditionPicker(
                        onJava = { openMainLauncher() },
                        onCrossplayInfo = { ElyByAuth.openInBrowser(ctx, "https://geysermc.org/wiki/geyser/") },
                    )
                    1 -> ProfileScreen(
                        accounts = accs, activeUuid = active,
                        onSelect = accounts::select, onAdd = { accounts.upsert(it); toast("Conta ${it.name} adicionada") }, onRemove = accounts::remove,
                        onMicrosoftLogin = { toast("Use o login Microsoft da tela principal do launcher") ; openMainLauncher() },
                        onPickSkin = { a, u, slim -> saveImage(a, u, cape = false, slim = slim) },
                        onPickCape = { a, u -> saveImage(a, u, cape = true, slim = false) },
                        onExport = { exporter.launch("picareta-backup.zip") }, onImport = { importer.launch(arrayOf("application/zip", "application/octet-stream")) },
                    )
                    2 -> {
                        val vm: ContentViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                            @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = ContentViewModel(null, null) as T
                        })
                        ContentBrowserScreen(vm, onInstall = { _, f ->
                            lifecycleScope.launch {
                                runCatching { installer.install(installer.download(f)) }
                                    .onSuccess { r -> toast(when (r) {
                                        is InstallResult.Installed -> "Instalado em ${r.file.parentFile?.name}"
                                        is InstallResult.SentToBedrock -> if (r.ok) "Enviado pro Minecraft Bedrock" else "Instale o Bedrock primeiro"
                                        is InstallResult.NeedsModpackInstaller -> "Modpack baixado: importe na tela de instâncias"
                                        is InstallResult.NeedsWorldPick -> "Datapack: escolha um mundo"
                                    }) }
                                    .onFailure { toast(it.message ?: "Falhou") }
                            }
                        }, onOpenWebsite = { ElyByAuth.openInBrowser(ctx, it) })
                    }
                    else -> ConfigScreen(settings, onExport = { exporter.launch("picareta-backup.zip") }, onImport = { importer.launch(arrayOf("application/zip", "application/octet-stream")) })
                }
            }
        }
    }
}

@Composable
private fun HubTheme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = if (android.os.Build.VERSION.SDK_INT >= 31) { if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx) }
        else if (dark) darkColorScheme() else lightColorScheme()
    MaterialTheme(colorScheme = scheme, content = content)
}
