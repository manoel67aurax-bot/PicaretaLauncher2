package app.picareta.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import app.picareta.core.auth.Account
import app.picareta.core.auth.ElyByAuth
import app.picareta.core.auth.OfflineAccounts
import kotlinx.coroutines.launch

/**
 * Aba Perfil: conta ativa (com chroma), botão de Skin/Capa, lista de contas e "Adicionar/Criar conta".
 * Microsoft continua no fluxo do Zalith 2+: [onMicrosoftLogin] chama a tela de login existente.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    accounts: List<Account>,
    activeUuid: String?,
    onSelect: (Account) -> Unit,
    onAdd: (Account) -> Unit,
    onRemove: (Account) -> Unit,
    onMicrosoftLogin: () -> Unit,
    onPickSkin: (Account, Uri, slim: Boolean) -> Unit,
    onPickCape: (Account, Uri) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
) {
    val active = accounts.firstOrNull { it.uuid == activeUuid } ?: accounts.firstOrNull()
    var showAdd by remember { mutableStateOf(false) }
    var slim by remember { mutableStateOf(active?.skin?.slim ?: false) }
    val skinPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null && active != null) onPickSkin(active, uri, slim)
    }
    val capePicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null && active != null) onPickCape(active, uri)
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    if (active == null) {
                        Text("Nenhuma conta ainda", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { showAdd = true }) { Text("Adicionar conta") }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SkinHead(active, Modifier.size(64.dp))
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                ChromaName(active.name, active.chroma, style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold))
                                AssistChip(onClick = {}, label = { Text(active.typeLabel()) })
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { skinPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Outlined.Checkroom, null); Spacer(Modifier.width(8.dp)); Text("Skin")
                            }
                            FilledTonalButton(onClick = { capePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Outlined.Flag, null); Spacer(Modifier.width(8.dp)); Text("Capa")
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Modelo slim (braço fino)", Modifier.weight(1f))
                            Switch(checked = slim, onCheckedChange = { slim = it })
                        }
                        if (active is Account.Microsoft) {
                            Text("Skin da conta Microsoft muda em minecraft.net; aqui é só a pré-visualização local.",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Contas", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = onImport) { Text("Importar") }
                TextButton(onClick = onExport) { Text("Exportar") }
                FilledTonalIconButton(onClick = { showAdd = true }) { Icon(Icons.Outlined.PersonAdd, "Adicionar conta") }
            }
        }
        items(accounts, key = { it.uuid }) { acc ->
            ListItem(
                headlineContent = { ChromaName(acc.name, acc.chroma) },
                supportingContent = { Text(acc.typeLabel()) },
                leadingContent = { SkinHead(acc, Modifier.size(40.dp)) },
                trailingContent = {
                    Row {
                        if (acc.uuid == active?.uuid) Icon(Icons.Outlined.CheckCircle, "Ativa", tint = MaterialTheme.colorScheme.primary)
                        IconButton(onClick = { onRemove(acc) }) { Icon(Icons.Outlined.DeleteOutline, "Remover") }
                    }
                },
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onSelect(acc) },
                colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            )
        }
    }

    if (showAdd) AddAccountSheet(onDismiss = { showAdd = false }, onMicrosoft = { showAdd = false; onMicrosoftLogin() }, onAdded = { showAdd = false; onAdd(it) })
}

fun Account.typeLabel() = when (this) {
    is Account.Microsoft -> "Microsoft"
    is Account.ElyBy -> "Ely.by"
    is Account.Offline -> "Offline"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddAccountSheet(onDismiss: () -> Unit, onMicrosoft: () -> Unit, onAdded: (Account) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var name by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var totp by remember { mutableStateOf("") }
    var need2fa by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Adicionar conta", style = MaterialTheme.typography.titleLarge)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("Microsoft", "Ely.by", "Offline").forEachIndexed { i, l ->
                    SegmentedButton(selected = tab == i, onClick = { tab = i; error = null }, shape = SegmentedButtonDefaults.itemShape(i, 3)) { Text(l) }
                }
            }
            when (tab) {
                0 -> {
                    Text("Login oficial no navegador. Precisa ter o Minecraft Java comprado.", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = onMicrosoft, Modifier.fillMaxWidth()) { Text("Entrar com Microsoft") }
                    OutlinedButton(onClick = { ElyByAuth.openInBrowser(ctx, ElyByAuth.MS_SIGNUP_URL) }, Modifier.fillMaxWidth()) { Text("Criar conta Microsoft") }
                }
                1 -> {
                    OutlinedTextField(name, { name = it }, label = { Text("Usuário ou e-mail") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(pass, { pass = it }, label = { Text("Senha") }, singleLine = true, visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth())
                    if (need2fa) OutlinedTextField(totp, { totp = it.filter(Char::isDigit).take(6) }, label = { Text("Código 2FA") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth())
                    Button(enabled = !loading && name.isNotBlank() && pass.isNotBlank(), modifier = Modifier.fillMaxWidth(), onClick = {
                        loading = true; error = null
                        scope.launch {
                            try { onAdded(ElyByAuth.login(name, pass, totp.ifBlank { null })) }
                            catch (e: ElyByAuth.TwoFactorRequired) { need2fa = true; error = e.message }
                            catch (e: Exception) { error = e.message ?: "Falhou" }
                            finally { loading = false; pass = if (need2fa) pass else "" }
                        }
                    }) { if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Entrar com Ely.by") }
                    OutlinedButton(onClick = { ElyByAuth.openInBrowser(ctx, ElyByAuth.REGISTER_URL) }, Modifier.fillMaxWidth()) { Text("Criar conta Ely.by") }
                }
                else -> {
                    OutlinedTextField(name, { name = it.take(16); error = OfflineAccounts.validate(name) }, label = { Text("Nome do jogador") },
                        singleLine = true, supportingText = { Text(error ?: "3 a 16 letras, números ou _") }, isError = error != null, modifier = Modifier.fillMaxWidth())
                    Text("Offline serve pra singleplayer e servidores sem verificação. Skin/capa ficam locais.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(enabled = OfflineAccounts.validate(name) == null, modifier = Modifier.fillMaxWidth(), onClick = { onAdded(OfflineAccounts.create(name)) }) { Text("Criar conta offline") }
                }
            }
            if (tab != 2) error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
    }
}
