package app.picareta.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.TextStyle
import app.picareta.core.auth.ChromaStyle

/** Nome com gradiente andando. Usa só uma animação por nome, barato até em celular fraco. */
@Composable
fun ChromaName(name: String, chroma: ChromaStyle?, modifier: Modifier = Modifier, style: TextStyle = LocalTextStyle.current) {
    if (chroma == null) { Text(name, modifier, style = style); return }
    val shift by rememberInfiniteTransition(label = "chroma").animateFloat(
        0f, 600f, infiniteRepeatable(tween(chroma.speedMs, easing = LinearEasing), RepeatMode.Restart), label = "shift",
    )
    val colors = chroma.colors.map { Color(it) }.let { it + it.first() }
    val brush = Brush.linearGradient(colors, start = Offset(shift, 0f), end = Offset(shift + 300f, 0f), tileMode = TileMode.Repeated)
    Text(name, modifier, style = style.copy(brush = brush))
}
