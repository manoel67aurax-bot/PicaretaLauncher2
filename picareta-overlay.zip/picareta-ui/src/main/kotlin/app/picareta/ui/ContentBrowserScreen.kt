package app.picareta.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.picareta.core.net.*
import coil3.compose.AsyncImage
import kotlinx.coroutines.launch

/** Aba Baixar: mods, modpacks, texturas, shaders, datapacks e mundos do Modrinth e CurseForge. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentBrowserScreen(vm: ContentViewModel, onInstall: (ContentItem, ContentFile) -> Unit, onOpenWebsite: (String) -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf(s.query.text) }
    var picking by remember { mutableStateOf<ContentItem?>(null) }
    val list = rememberLazyListState()
    val nearEnd by remember { derivedStateOf { list.layoutInfo.visibleItemsInfo.lastOrNull()?.index?.let { it >= s.items.size - 5 } == true } }
    LaunchedEffect(nearEnd) { if (nearEnd) vm.loadMore() }

    Column(Modifier.fillMaxSize()) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Source.entries.forEachIndexed { i, src ->
                SegmentedButton(selected = s.source == src, onClick = { vm.onSource(src) }, shape = SegmentedButtonDefaults.itemShape(i, 2)) {
                    Text(if (src == Source.MODRINTH) "Modrinth" else "CurseForge")
                }
            }
        }
        OutlinedTextField(text, { text = it; vm.onText(it) }, Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Buscar ${s.query.type.label.lowercase()}") }, leadingIcon = { Icon(Icons.Outlined.Search, null) },
            singleLine = true, shape = RoundedCornerShape(28.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ContentType.entries.forEach { t -> FilterChip(selected = s.query.type == t, onClick = { vm.onType(t) }, label = { Text(t.label) }) }
        }
        s.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        LazyColumn(state = list, contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(s.items, key = { "${it.source}:${it.id}" }) { item ->
                Card(onClick = { picking = item }, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(item.iconUrl, null, Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.description, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${item.author} · ${compact(item.downloads)} downloads", style = MaterialTheme.typography.labelSmall)
                        }
                        Icon(Icons.Outlined.Download, "Instalar")
                    }
                }
            }
            if (s.loading) item { Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator() } }
        }
    }

    picking?.let { item -> VersionSheet(vm, item, onDismiss = { picking = null }, onInstall = { f -> picking = null; onInstall(item, f) }, onOpenWebsite = onOpenWebsite) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VersionSheet(vm: ContentViewModel, item: ContentItem, onDismiss: () -> Unit, onInstall: (ContentFile) -> Unit, onOpenWebsite: (String) -> Unit) {
    val files by produceState<Result<List<ContentFile>>?>(null, item) { value = runCatching { vm.files(item) } }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text(item.title, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            when (val r = files) {
                null -> LinearProgressIndicator(Modifier.fillMaxWidth())
                else -> r.fold(
                    onSuccess = { list ->
                        if (list.isEmpty()) Text("Nenhuma versão compatível com essa instância")
                        LazyColumn(Modifier.heightIn(max = 420.dp)) {
                            items(list.take(30)) { f ->
                                ListItem(
                                    headlineContent = { Text(f.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    supportingContent = { Text((f.loaders + f.gameVersions.take(3)).joinToString(" · ")) },
                                    trailingContent = {
                                        if (f.url != null) FilledTonalButton(onClick = { onInstall(f) }) { Text("Instalar") }
                                        else TextButton(onClick = { f.websiteUrl?.let(onOpenWebsite) }) { Text("Abrir site") }
                                    },
                                )
                            }
                        }
                    },
                    onFailure = { Text(it.message ?: "Erro", color = MaterialTheme.colorScheme.error) },
                )
            }
        }
    }
}

private fun compact(n: Long) = when {
    n >= 1_000_000 -> "%.1fM".format(n / 1_000_000.0)
    n >= 1_000 -> "%.1fk".format(n / 1_000.0)
    else -> n.toString()
}
