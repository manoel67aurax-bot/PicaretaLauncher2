package app.picareta.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.picareta.core.bedrock.BedrockBridge

/**
 * "Qual Minecraft?": Java (motor do launcher), Bedrock (abre o app oficial) e Crossplay
 * (servidor Java com Geyser + Floodgate, onde Java e Bedrock jogam juntos).
 */
@Composable
fun EditionPicker(onJava: () -> Unit, onCrossplayInfo: () -> Unit) {
    val ctx = LocalContext.current
    val bedrock = BedrockBridge.isInstalled(ctx)
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        EditionCard("Java Edition", "Versões release, snapshot, Fabric, Forge, NeoForge, Quilt", "Jogar", onJava)
        EditionCard("Bedrock Edition", if (bedrock) "Abre o app oficial. Packs e addons importam direto." else "Precisa do app oficial da Play Store",
            if (bedrock) "Abrir" else "Ver na Play Store") { if (bedrock) BedrockBridge.launch(ctx) else BedrockBridge.openStore(ctx) }
        EditionCard("Java + Bedrock juntos", "Servidores com Geyser: amigos no Bedrock entram no seu mundo Java", "Como funciona", onCrossplayInfo)
        Text("Versão não oficial baseada no Zalith Launcher 2 / 2+ (GPL-3.0). Não afiliado à Mojang ou Microsoft.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EditionCard(title: String, body: String, action: String, onClick: () -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onClick) { Text(action) }
        }
    }
}
