package app.picareta.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import app.picareta.core.auth.Account
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Recorta o rosto (8x8 + camada do chapéu) da skin local. Sem skin: inicial do nome. */
@Composable
fun SkinHead(account: Account, modifier: Modifier) {
    val head = produceState<Bitmap?>(null, account.skin?.path) {
        value = withContext(Dispatchers.IO) { account.skin?.path?.let { cropHead(File(it)) } }
    }.value
    val shape = RoundedCornerShape(12)
    if (head != null) {
        Image(head.asImageBitmap(), account.name, modifier.clip(shape), contentScale = ContentScale.Fit, filterQuality = FilterQuality.None)
    } else {
        Box(modifier.clip(shape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
            Text(account.name.take(1).uppercase(), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
        }
    }
}

private fun cropHead(f: File): Bitmap? = runCatching {
    val src = BitmapFactory.decodeFile(f.absolutePath) ?: return null
    val s = src.width / 64
    val out = Bitmap.createBitmap(8 * s, 8 * s, Bitmap.Config.ARGB_8888)
    val c = android.graphics.Canvas(out)
    c.drawBitmap(Bitmap.createBitmap(src, 8 * s, 8 * s, 8 * s, 8 * s), 0f, 0f, null)
    c.drawBitmap(Bitmap.createBitmap(src, 40 * s, 8 * s, 8 * s, 8 * s), 0f, 0f, null) // camada externa
    out
}.getOrNull()
