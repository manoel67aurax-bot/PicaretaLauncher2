package app.picareta.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import app.picareta.core.net.*
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class BrowserState(
    val query: SearchQuery = SearchQuery(),
    val source: Source = Source.MODRINTH,
    val items: List<ContentItem> = emptyList(),
    val loading: Boolean = false,
    val endReached: Boolean = false,
    val error: String? = null,
)

/** Busca com debounce (respeita o limite de 300 req/min do Modrinth) e paginação infinita. */
@OptIn(FlowPreview::class)
class ContentViewModel(gameVersion: String?, loader: String?) : ViewModel() {
    private val _state = MutableStateFlow(BrowserState(SearchQuery(gameVersion = gameVersion, loader = loader)))
    val state = _state.asStateFlow()
    private val text = MutableStateFlow("")
    private var job: Job? = null

    init {
        viewModelScope.launch { text.debounce(350).distinctUntilChanged().collect { reload { copy(text = it) } } }
    }

    private fun api() = if (_state.value.source == Source.MODRINTH) ModrinthApi else CurseForgeApi

    fun onText(t: String) { text.value = t }
    fun onType(t: ContentType) = reload { copy(type = t) }
    fun onSource(s: Source) { _state.update { it.copy(source = s) }; reload { this } }

    private fun reload(change: SearchQuery.() -> SearchQuery) {
        _state.update { it.copy(query = it.query.change().copy(page = 0), items = emptyList(), endReached = false) }
        load()
    }

    fun loadMore() { val s = _state.value; if (!s.loading && !s.endReached) { _state.update { it.copy(query = it.query.copy(page = it.query.page + 1)) }; load() } }

    private fun load() {
        job?.cancel()
        job = viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            runCatching { api().search(_state.value.query) }
                .onSuccess { r -> _state.update { it.copy(items = it.items + r, loading = false, endReached = r.size < it.query.pageSize) } }
                .onFailure { e -> _state.update { it.copy(loading = false, error = e.message) } }
        }
    }

    suspend fun files(item: ContentItem): List<ContentFile> = api().files(item, _state.value.query.gameVersion, _state.value.query.loader)
}
