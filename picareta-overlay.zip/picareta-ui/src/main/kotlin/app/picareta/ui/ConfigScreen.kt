package app.picareta.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.picareta.core.settings.*
import kotlin.math.roundToInt

/**
 * Config remake: presets no topo, busca, seções em cards. Qualquer ajuste manual vira "Personalizado".
 * Mostra a RAM do aparelho pra pessoa não colocar 6 GB num celular de 4.
 */
@Composable
fun ConfigScreen(repo: SettingsRepository, onExport: () -> Unit, onImport: () -> Unit) {
    val s by repo.state.collectAsStateWithLifecycle()
    var q by remember { mutableStateOf("") }
    fun set(t: PicaretaSettings.() -> PicaretaSettings) = repo.update { it.t().copy(preset = Preset.CUSTOM) }
    fun show(vararg words: String) = q.isBlank() || words.any { it.contains(q.trim(), ignoreCase = true) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Buscar configuração") },
                leadingIcon = { Icon(Icons.Outlined.Search, null) }, singleLine = true, shape = RoundedCornerShape(28.dp))
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Preset.entries.filter { it != Preset.CUSTOM }.forEach { p ->
                    FilterChip(selected = s.preset == p, onClick = { repo.update { it.applyPreset(p, repo.deviceRamMb) } }, label = { Text(p.label) })
                }
                if (s.preset == Preset.CUSTOM) AssistChip(onClick = {}, label = { Text("Personalizado") })
            }
        }
        item {
            Section("Desempenho", show("ram", "memória", "resolução", "fps", "desempenho")) {
                SliderRow("RAM pro jogo", s.ramMb.toFloat(), 1024f..(repo.deviceRamMb * 0.7f).coerceAtLeast(1536f), "${s.ramMb} MB de ${repo.deviceRamMb} MB", step = 256f) { set { copy(ramMb = it.roundToInt()) } }
                SliderRow("Resolução", s.resolutionScale.toFloat(), 25f..100f, "${s.resolutionScale}%", step = 5f) { set { copy(resolutionScale = it.roundToInt()) } }
                SliderRow("Limite de FPS", s.fpsLimit.toFloat(), 30f..144f, "${s.fpsLimit}", step = 30f) { set { copy(fpsLimit = it.roundToInt()) } }
                SwitchRow("Modo desempenho sustentado", "Evita queda de FPS por aquecimento", s.sustainedPerformance) { set { copy(sustainedPerformance = it) } }
            }
        }
        item {
            Section("Renderizador", show("render", "mobileglues", "zink", "gl4es", "shader", "angle")) {
                Renderer.entries.forEach { r ->
                    ListItem(
                        headlineContent = { Text(r.label) }, supportingContent = { Text(r.hint) },
                        leadingContent = { RadioButton(selected = s.renderer == r, onClick = { set { copy(renderer = r) } }) },
                    )
                }
            }
        }
        item {
            Section("Controles", show("controle", "bedrock", "gamepad", "vibração", "giroscópio", "opacidade")) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ControlStyle.entries.forEach { c -> FilterChip(selected = s.controls == c, onClick = { set { copy(controls = c) } }, label = { Text(c.label) }) }
                }
                SliderRow("Opacidade dos botões", s.controlOpacity.toFloat(), 20f..100f, "${s.controlOpacity}%", step = 10f) { set { copy(controlOpacity = it.roundToInt()) } }
                SwitchRow("Vibração ao tocar", null, s.hapticFeedback) { set { copy(hapticFeedback = it) } }
                SwitchRow("Câmera por giroscópio", null, s.gyroCamera) { set { copy(gyroCamera = it) } }
            }
        }
        item {
            Section("Launcher", show("chroma", "atalho", "tela inicial", "backup", "exportar", "importar")) {
                SwitchRow("Nomes chroma", "Gradiente animado no nome", s.chromaNames) { set { copy(chromaNames = it) } }
                SwitchRow("Atalhos na tela inicial", "Fixar instâncias no launcher do Android", s.homeShortcuts) { set { copy(homeShortcuts = it) } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(onClick = onExport, Modifier.weight(1f)) { Text("Exportar tudo") }
                    OutlinedButton(onClick = onImport, Modifier.weight(1f)) { Text("Importar") }
                }
            }
        }
        item {
            Section("Avançado", show("java", "argumentos", "jvm", "avançado")) {
                OutlinedTextField(s.javaArgs, { v -> set { copy(javaArgs = v) } }, Modifier.fillMaxWidth(), label = { Text("Argumentos da JVM") })
            }
        }
    }
}

@Composable
private fun Section(title: String, visible: Boolean, content: @Composable ColumnScope.() -> Unit) {
    AnimatedVisibility(visible) {
        ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                content()
            }
        }
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String, step: Float, onChange: (Float) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f)); Text(valueText, style = MaterialTheme.typography.labelLarge)
        }
        val steps = (((range.endInclusive - range.start) / step).toInt() - 1).coerceAtLeast(0)
        Slider(value.coerceIn(range), onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = if (subtitle != null) { { Text(subtitle) } } else null,
        trailingContent = { Switch(checked, onChange) },
    )
}
