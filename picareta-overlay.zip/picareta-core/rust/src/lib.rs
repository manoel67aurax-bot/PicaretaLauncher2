//! Picareta Core: ponte JNI fina. Tudo entra e sai como String/JSON pra manter a FFI simples e
//! nunca deixar um panic atravessar a fronteira (o perfil release usa panic=abort).
pub mod backup;
pub mod detect;
pub mod offline;
pub mod skin;

use jni::{
    objects::{JClass, JString},
    sys::jstring,
    JNIEnv,
};
use sha1::{Digest, Sha1};
use std::{fs::File, io::Read, path::Path};

fn ok<T: serde::Serialize>(v: T) -> String {
    serde_json::json!({ "ok": true, "value": v }).to_string()
}
fn err<E: std::fmt::Display>(m: E) -> String {
    serde_json::json!({ "ok": false, "error": m.to_string() }).to_string()
}

pub fn sha1_file(path: &Path) -> Result<String, String> {
    let mut f = File::open(path).map_err(|e| e.to_string())?;
    let mut h = Sha1::new();
    let mut buf = vec![0u8; 256 * 1024];
    loop {
        let n = f.read(&mut buf).map_err(|e| e.to_string())?;
        if n == 0 {
            break;
        }
        h.update(&buf[..n]);
    }
    Ok(h.finalize().iter().map(|b| format!("{b:02x}")).collect())
}

/// Executa `f` com a string Java convertida e devolve JSON {ok, value|error}.
fn call(env: &mut JNIEnv, input: &JString, f: impl FnOnce(String) -> String) -> jstring {
    let out = match env.get_string(input) {
        Ok(s) => f(s.into()),
        Err(e) => err(e),
    };
    env.new_string(out).map(|s| s.into_raw()).unwrap_or(std::ptr::null_mut())
}

#[no_mangle]
pub extern "system" fn Java_app_picareta_core_PicaretaNative_offlineUuid<'l>(mut env: JNIEnv<'l>, _c: JClass<'l>, name: JString<'l>) -> jstring {
    call(&mut env, &name, |n| {
        if offline::is_valid_name(&n) { ok(offline::offline_uuid(&n)) } else { err("Nome precisa ter 3 a 16 letras, números ou _") }
    })
}

#[no_mangle]
pub extern "system" fn Java_app_picareta_core_PicaretaNative_checkSkin<'l>(mut env: JNIEnv<'l>, _c: JClass<'l>, path: JString<'l>) -> jstring {
    call(&mut env, &path, |p| ok(skin::check_skin(Path::new(&p))))
}

#[no_mangle]
pub extern "system" fn Java_app_picareta_core_PicaretaNative_checkCape<'l>(mut env: JNIEnv<'l>, _c: JClass<'l>, path: JString<'l>) -> jstring {
    call(&mut env, &path, |p| ok(skin::check_cape(Path::new(&p))))
}

#[no_mangle]
pub extern "system" fn Java_app_picareta_core_PicaretaNative_detectContent<'l>(mut env: JNIEnv<'l>, _c: JClass<'l>, path: JString<'l>) -> jstring {
    call(&mut env, &path, |p| detect::detect(Path::new(&p)).map(ok).unwrap_or_else(err))
}

#[no_mangle]
pub extern "system" fn Java_app_picareta_core_PicaretaNative_sha1<'l>(mut env: JNIEnv<'l>, _c: JClass<'l>, path: JString<'l>) -> jstring {
    call(&mut env, &path, |p| sha1_file(Path::new(&p)).map(ok).unwrap_or_else(err))
}

#[no_mangle]
pub extern "system" fn Java_app_picareta_core_PicaretaNative_exportBackup<'l>(mut env: JNIEnv<'l>, _c: JClass<'l>, req: JString<'l>) -> jstring {
    call(&mut env, &req, |r| match serde_json::from_str::<backup::ExportRequest>(&r) {
        Ok(req) => backup::export(&req).map(ok).unwrap_or_else(err),
        Err(e) => err(e),
    })
}

#[no_mangle]
pub extern "system" fn Java_app_picareta_core_PicaretaNative_importBackup<'l>(mut env: JNIEnv<'l>, _c: JClass<'l>, req: JString<'l>) -> jstring {
    // req = {"zip": "...", "dest": "..."}
    call(&mut env, &req, |r| {
        let v: serde_json::Value = match serde_json::from_str(&r) { Ok(v) => v, Err(e) => return err(e) };
        let (Some(z), Some(d)) = (v["zip"].as_str(), v["dest"].as_str()) else { return err("zip/dest ausentes") };
        backup::import(Path::new(z), Path::new(d)).map(ok).unwrap_or_else(err)
    })
}
