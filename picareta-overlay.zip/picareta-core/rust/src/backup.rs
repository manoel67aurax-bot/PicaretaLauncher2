//! Exportar/importar configurações + contas + skins + capas num único arquivo .picareta (zip).
//! Segurança: tokens de login NUNCA entram no backup (Microsoft/Ely.by pedem login de novo).
use serde::{Deserialize, Serialize};
use std::{
    fs::{self, File},
    io::{self, Read, Write},
    path::{Path, PathBuf},
};
use zip::{write::SimpleFileOptions, CompressionMethod, ZipArchive, ZipWriter};

pub const FORMAT: u32 = 1;
const MAX_ENTRY: u64 = 32 * 1024 * 1024; // contra zip bomb
const MAX_ENTRIES: usize = 2000;
const SECRET_KEYS: [&str; 6] = ["accessToken", "refreshToken", "access_token", "refresh_token", "clientToken", "password"];

#[derive(Deserialize)]
pub struct ExportRequest {
    pub dest: String,
    pub settings_json: String,
    pub accounts_json: String,
    /// Arquivos extras (skins/capas): caminho local -> nome dentro do zip (ex: "skins/<uuid>.png").
    #[serde(default)]
    pub files: Vec<FileEntry>,
}

#[derive(Deserialize, Serialize)]
pub struct FileEntry {
    pub path: String,
    pub name: String,
}

#[derive(Serialize, Deserialize)]
pub struct Meta {
    pub format: u32,
    pub app: String,
    pub files: Vec<String>,
}

/// Remove recursivamente qualquer campo de token/senha.
pub fn strip_secrets(v: &mut serde_json::Value) {
    match v {
        serde_json::Value::Object(m) => {
            for k in SECRET_KEYS {
                m.remove(k);
            }
            m.values_mut().for_each(strip_secrets);
        }
        serde_json::Value::Array(a) => a.iter_mut().for_each(strip_secrets),
        _ => {}
    }
}

fn safe_name(n: &str) -> bool {
    !n.is_empty() && !n.starts_with('/') && !n.contains("..") && !n.contains('\\')
}

pub fn export(req: &ExportRequest) -> Result<Meta, String> {
    let mut accounts: serde_json::Value = serde_json::from_str(&req.accounts_json).map_err(|e| format!("contas: {e}"))?;
    strip_secrets(&mut accounts);
    let settings: serde_json::Value = serde_json::from_str(&req.settings_json).map_err(|e| format!("config: {e}"))?;

    let tmp = format!("{}.tmp", req.dest);
    let mut zw = ZipWriter::new(File::create(&tmp).map_err(|e| e.to_string())?);
    let opt = SimpleFileOptions::default().compression_method(CompressionMethod::Deflated);
    let mut names = vec!["settings.json".to_string(), "accounts.json".to_string()];

    let put = |zw: &mut ZipWriter<File>, name: &str, data: &[u8]| -> Result<(), String> {
        zw.start_file(name, opt).map_err(|e| e.to_string())?;
        zw.write_all(data).map_err(|e| e.to_string())
    };
    put(&mut zw, "settings.json", serde_json::to_string_pretty(&settings).unwrap().as_bytes())?;
    put(&mut zw, "accounts.json", serde_json::to_string_pretty(&accounts).unwrap().as_bytes())?;
    for f in &req.files {
        if !safe_name(&f.name) {
            return Err(format!("nome inválido: {}", f.name));
        }
        let data = fs::read(&f.path).map_err(|e| format!("{}: {e}", f.path))?;
        put(&mut zw, &f.name, &data)?;
        names.push(f.name.clone());
    }
    let meta = Meta { format: FORMAT, app: "picareta".into(), files: names };
    put(&mut zw, "backup.json", serde_json::to_string_pretty(&meta).unwrap().as_bytes())?;
    zw.finish().map_err(|e| e.to_string())?;
    fs::rename(&tmp, &req.dest).map_err(|e| e.to_string())?; // escrita atômica
    Ok(meta)
}

/// Extrai o backup em `dest_dir` (pasta temporária). O app Kotlin lê settings.json/accounts.json
/// e decide o que mesclar. Bloqueia zip-slip e arquivos gigantes.
pub fn import(zip_path: &Path, dest_dir: &Path) -> Result<Meta, String> {
    let mut ar = ZipArchive::new(File::open(zip_path).map_err(|e| e.to_string())?).map_err(|_| "Backup corrompido".to_string())?;
    if ar.len() > MAX_ENTRIES {
        return Err("Backup com arquivos demais".into());
    }
    let meta: Meta = {
        let mut s = String::new();
        ar.by_name("backup.json").map_err(|_| "Não é um backup do Picareta".to_string())?.take(1 << 20).read_to_string(&mut s).map_err(|e| e.to_string())?;
        serde_json::from_str(&s).map_err(|e| e.to_string())?
    };
    if meta.format > FORMAT {
        return Err("Backup feito numa versão mais nova do launcher".into());
    }
    fs::create_dir_all(dest_dir).map_err(|e| e.to_string())?;
    for i in 0..ar.len() {
        let mut entry = ar.by_index(i).map_err(|e| e.to_string())?;
        let rel: PathBuf = match entry.enclosed_name() {
            Some(p) => p,
            None => continue, // caminho malicioso, ignora
        };
        if entry.is_dir() {
            continue;
        }
        if entry.size() > MAX_ENTRY {
            return Err(format!("{} grande demais", rel.display()));
        }
        let out = dest_dir.join(rel);
        if let Some(parent) = out.parent() {
            fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        let mut f = File::create(&out).map_err(|e| e.to_string())?;
        io::copy(&mut (&mut entry).take(MAX_ENTRY), &mut f).map_err(|e| e.to_string())?;
    }
    Ok(meta)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn roundtrip_without_tokens() {
        let dir = tempfile::tempdir().unwrap();
        let skin = dir.path().join("s.png");
        fs::write(&skin, b"png").unwrap();
        let dest = dir.path().join("b.picareta");
        let req = ExportRequest {
            dest: dest.to_string_lossy().into(),
            settings_json: r#"{"ram":3072}"#.into(),
            accounts_json: r#"[{"name":"Pedro","type":"microsoft","refreshToken":"SEGREDO","accessToken":"X"}]"#.into(),
            files: vec![FileEntry { path: skin.to_string_lossy().into(), name: "skins/pedro.png".into() }],
        };
        export(&req).unwrap();
        let out = dir.path().join("out");
        import(&dest, &out).unwrap();
        let acc = fs::read_to_string(out.join("accounts.json")).unwrap();
        assert!(acc.contains("Pedro"));
        assert!(!acc.contains("SEGREDO"));
        assert!(out.join("skins/pedro.png").exists());
    }
}
