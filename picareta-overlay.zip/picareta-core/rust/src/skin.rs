//! Validação de skin e capa lendo só o cabeçalho PNG (rápido, sem decodificar a imagem).
use serde::Serialize;
use std::{fs::File, io::Read, path::Path};

#[derive(Serialize, Debug, PartialEq)]
pub struct ImageCheck {
    pub ok: bool,
    pub width: u32,
    pub height: u32,
    pub kind: String,
    pub message: String,
}

const PNG_SIG: [u8; 8] = [0x89, b'P', b'N', b'G', 0x0D, 0x0A, 0x1A, 0x0A];
const MAX_BYTES: u64 = 2 * 1024 * 1024;

pub fn png_size(path: &Path) -> Result<(u32, u32), String> {
    let meta = std::fs::metadata(path).map_err(|e| e.to_string())?;
    if meta.len() > MAX_BYTES {
        return Err("Arquivo maior que 2 MB".into());
    }
    let mut head = [0u8; 24];
    File::open(path).and_then(|mut f| f.read_exact(&mut head)).map_err(|_| "Não é um PNG válido".to_string())?;
    if head[0..8] != PNG_SIG || &head[12..16] != b"IHDR" {
        return Err("Não é um PNG válido".into());
    }
    let w = u32::from_be_bytes(head[16..20].try_into().unwrap());
    let h = u32::from_be_bytes(head[20..24].try_into().unwrap());
    Ok((w, h))
}

fn pow2_multiple(v: u32, base: u32) -> bool {
    v >= base && v % base == 0 && (v / base).is_power_of_two()
}

pub fn check_skin(path: &Path) -> ImageCheck {
    match png_size(path) {
        Err(m) => ImageCheck { ok: false, width: 0, height: 0, kind: "invalid".into(), message: m },
        Ok((w, h)) => {
            let (ok, kind, msg) = if w == 64 && h == 64 {
                (true, "modern", "Skin 64×64 ok")
            } else if w == 64 && h == 32 {
                (true, "legacy", "Skin antiga 64×32 (sem camada extra)")
            } else if w == h && pow2_multiple(w, 64) {
                (true, "hd", "Skin HD: só aparece com mod de skins HD")
            } else {
                (false, "invalid", "Skin precisa ser 64×64 ou 64×32")
            };
            ImageCheck { ok, width: w, height: h, kind: kind.into(), message: msg.into() }
        }
    }
}

pub fn check_cape(path: &Path) -> ImageCheck {
    match png_size(path) {
        Err(m) => ImageCheck { ok: false, width: 0, height: 0, kind: "invalid".into(), message: m },
        Ok((w, h)) => {
            let (ok, kind, msg) = if (w, h) == (64, 32) {
                (true, "standard", "Capa 64×32 ok")
            } else if (w, h) == (22, 17) {
                (true, "legacy", "Capa antiga 22×17")
            } else if pow2_multiple(w, 64) && h * 2 == w {
                (true, "hd", "Capa HD ok")
            } else {
                (false, "invalid", "Capa precisa ser 64×32 (ou HD 2:1)")
            };
            ImageCheck { ok, width: w, height: h, kind: kind.into(), message: msg.into() }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    fn fake_png(w: u32, h: u32) -> tempfile::NamedTempFile {
        let mut f = tempfile::NamedTempFile::new().unwrap();
        f.write_all(&PNG_SIG).unwrap();
        f.write_all(&13u32.to_be_bytes()).unwrap();
        f.write_all(b"IHDR").unwrap();
        f.write_all(&w.to_be_bytes()).unwrap();
        f.write_all(&h.to_be_bytes()).unwrap();
        f
    }
    #[test]
    fn skins() {
        assert!(check_skin(fake_png(64, 64).path()).ok);
        assert_eq!(check_skin(fake_png(64, 32).path()).kind, "legacy");
        assert!(check_skin(fake_png(128, 128).path()).ok);
        assert!(!check_skin(fake_png(100, 64).path()).ok);
    }
    #[test]
    fn capes() {
        assert!(check_cape(fake_png(64, 32).path()).ok);
        assert!(check_cape(fake_png(128, 64).path()).ok);
        assert!(!check_cape(fake_png(64, 64).path()).ok);
    }
}
