//! Descobre o que é um arquivo (mod, resource pack, shader, datapack, mundo, modpack, pack Bedrock)
//! olhando o conteúdo do zip, não só a extensão.
use serde::Serialize;
use std::{fs::File, io::Read, path::Path};

#[derive(Serialize, Debug, PartialEq, Clone, Copy)]
#[serde(rename_all = "snake_case")]
pub enum ContentKind {
    Mod,
    ResourcePack,
    ShaderPack,
    DataPack,
    World,
    ModrinthModpack,
    CurseforgeModpack,
    BedrockPack,
    BedrockWorld,
    Unknown,
}

#[derive(Serialize, Debug)]
pub struct Detection {
    pub kind: ContentKind,
    /// Loader do mod quando dá pra saber: fabric, quilt, forge, neoforge.
    pub loader: Option<String>,
    /// Para mundos dentro de uma pasta no zip: prefixo até o level.dat.
    pub root: Option<String>,
}

fn ext(path: &Path) -> String {
    path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase()
}

pub fn detect(path: &Path) -> Result<Detection, String> {
    let e = ext(path);
    match e.as_str() {
        "mcpack" | "mcaddon" | "mctemplate" => return Ok(Detection { kind: ContentKind::BedrockPack, loader: None, root: None }),
        "mcworld" => return Ok(Detection { kind: ContentKind::BedrockWorld, loader: None, root: None }),
        "mrpack" => return Ok(Detection { kind: ContentKind::ModrinthModpack, loader: None, root: None }),
        _ => {}
    }
    let file = File::open(path).map_err(|e| e.to_string())?;
    let mut zip = zip::ZipArchive::new(file).map_err(|_| "Arquivo não é zip/jar".to_string())?;
    let names: Vec<String> = zip.file_names().map(|s| s.replace('\\', "/")).collect();
    let has = |n: &str| names.iter().any(|x| x == n);
    let has_prefix = |p: &str| names.iter().any(|x| x.starts_with(p));

    // Mods
    let loader = if has("fabric.mod.json") {
        Some("fabric")
    } else if has("quilt.mod.json") {
        Some("quilt")
    } else if has("META-INF/neoforge.mods.toml") {
        Some("neoforge")
    } else if has("META-INF/mods.toml") || has("mcmod.info") {
        Some("forge")
    } else {
        None
    };
    if let Some(l) = loader {
        return Ok(Detection { kind: ContentKind::Mod, loader: Some(l.into()), root: None });
    }
    if has("modrinth.index.json") {
        return Ok(Detection { kind: ContentKind::ModrinthModpack, loader: None, root: None });
    }
    if has("manifest.json") {
        let mut s = String::new();
        if let Ok(f) = zip.by_name("manifest.json") {
            let _ = f.take(1 << 20).read_to_string(&mut s);
        }
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(&s) {
            if v.get("minecraft").is_some() {
                return Ok(Detection { kind: ContentKind::CurseforgeModpack, loader: None, root: None });
            }
            if v.get("header").is_some() && v.get("format_version").is_some() {
                return Ok(Detection { kind: ContentKind::BedrockPack, loader: None, root: None });
            }
        }
    }
    if has_prefix("shaders/") {
        return Ok(Detection { kind: ContentKind::ShaderPack, loader: None, root: None });
    }
    if let Some(level) = names.iter().filter(|n| n.ends_with("level.dat")).min_by_key(|n| n.len()) {
        let root = level.trim_end_matches("level.dat").to_string();
        return Ok(Detection { kind: ContentKind::World, loader: None, root: Some(root) });
    }
    if has("pack.mcmeta") {
        let kind = if has_prefix("data/") && !has_prefix("assets/") { ContentKind::DataPack } else { ContentKind::ResourcePack };
        return Ok(Detection { kind, loader: None, root: None });
    }
    Ok(Detection { kind: ContentKind::Unknown, loader: None, root: None })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;
    use zip::write::SimpleFileOptions;

    fn make_zip(ext: &str, files: &[(&str, &str)]) -> tempfile::TempPath {
        let f = tempfile::Builder::new().suffix(ext).tempfile().unwrap();
        let mut w = zip::ZipWriter::new(f.reopen().unwrap());
        for (n, c) in files {
            w.start_file(*n, SimpleFileOptions::default()).unwrap();
            w.write_all(c.as_bytes()).unwrap();
        }
        w.finish().unwrap();
        f.into_temp_path()
    }

    #[test]
    fn detects_everything() {
        assert_eq!(detect(&make_zip(".jar", &[("fabric.mod.json", "{}")])).unwrap().loader.as_deref(), Some("fabric"));
        assert_eq!(detect(&make_zip(".zip", &[("shaders/composite.fsh", "")])).unwrap().kind, ContentKind::ShaderPack);
        assert_eq!(detect(&make_zip(".zip", &[("pack.mcmeta", "{}"), ("assets/a.png", "")])).unwrap().kind, ContentKind::ResourcePack);
        assert_eq!(detect(&make_zip(".zip", &[("pack.mcmeta", "{}"), ("data/x.json", "")])).unwrap().kind, ContentKind::DataPack);
        let w = detect(&make_zip(".zip", &[("Meu Mundo/level.dat", "")])).unwrap();
        assert_eq!(w.kind, ContentKind::World);
        assert_eq!(w.root.as_deref(), Some("Meu Mundo/"));
        assert_eq!(detect(&make_zip(".zip", &[("manifest.json", r#"{"minecraft":{}}"#)])).unwrap().kind, ContentKind::CurseforgeModpack);
        assert_eq!(detect(&make_zip(".zip", &[("manifest.json", r#"{"format_version":2,"header":{}}"#)])).unwrap().kind, ContentKind::BedrockPack);
    }
}
