//! Contas offline: mesma regra do servidor vanilla (UUID v3 de "OfflinePlayer:<nome>").
use md5::{Digest, Md5};

/// Nome válido no Java Edition: 3..=16 chars, [A-Za-z0-9_].
pub fn is_valid_name(name: &str) -> bool {
    (3..=16).contains(&name.len()) && name.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
}

pub fn offline_uuid(name: &str) -> String {
    let mut b = [0u8; 16];
    b.copy_from_slice(&Md5::digest(format!("OfflinePlayer:{name}").as_bytes()));
    b[6] = (b[6] & 0x0f) | 0x30; // versão 3
    b[8] = (b[8] & 0x3f) | 0x80; // variante IETF
    let h: String = b.iter().map(|x| format!("{x:02x}")).collect();
    format!("{}-{}-{}-{}-{}", &h[0..8], &h[8..12], &h[12..16], &h[16..20], &h[20..32])
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn matches_vanilla_server() {
        assert_eq!(offline_uuid("Notch"), "b50ad385-829d-3141-a216-7e7d7539ba7f");
        assert_eq!(offline_uuid("Steve"), "5627dd98-e6be-3c21-b8a8-e92344183641");
    }
    #[test]
    fn names() {
        assert!(is_valid_name("Pedro_123"));
        assert!(!is_valid_name("ab"));
        assert!(!is_valid_name("nome com espaço"));
        assert!(!is_valid_name("abcdefghijklmnopq"));
    }
}
