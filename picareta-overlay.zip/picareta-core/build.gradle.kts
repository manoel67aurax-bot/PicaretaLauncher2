// Módulo Android library: Kotlin + Rust (via cargo-ndk). Segue o padrão do Zalith 2+ (AGP 9, Kotlin embutido).
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.library)
    id("kotlinx-serialization")
}

android {
    namespace = "app.picareta.core"
    compileSdk = 37
    defaultConfig {
        minSdk = 26
        consumerProguardFiles("consumer-rules.pro")
        buildConfigField("String", "CURSEFORGE_API_KEY", "\"${System.getenv("CURSEFORGE_API_KEY") ?: (findProperty("CURSEFORGE_API_KEY") ?: "")}\"")
        buildConfigField("String", "USER_AGENT", "\"${findProperty("PICARETA_UA") ?: "seu-github/picareta-launcher/1.0.0 (seu-email@exemplo.com)"}\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    sourceSets {
        getByName("debug") { jniLibs.srcDir(layout.buildDirectory.dir("rustJniLibs/debug").get().asFile.path) }
        getByName("release") { jniLibs.srcDir(layout.buildDirectory.dir("rustJniLibs/release").get().asFile.path) }
    }
}

// -Darch=all|arm|arm64|x86|x86_64 (mesmo parâmetro que o CI do Zalith usa)
val abis: List<String> = when (System.getProperty("arch") ?: "all") {
    "arm" -> listOf("armeabi-v7a")
    "arm64" -> listOf("arm64-v8a")
    "x86" -> listOf("x86")
    "x86_64" -> listOf("x86_64")
    else -> listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86")
}
val rustDir = layout.projectDirectory.dir("rust")

fun registerCargo(buildType: String, release: Boolean) =
    tasks.register<Exec>("cargoBuild${buildType.replaceFirstChar { it.uppercase() }}") {
        group = "build"
        description = "Compila o picareta_core (Rust) para $abis"
        val out = layout.buildDirectory.dir("rustJniLibs/$buildType")
        workingDir = rustDir.asFile
        inputs.dir(rustDir.dir("src"))
        inputs.file(rustDir.file("Cargo.toml"))
        inputs.property("abis", abis)
        outputs.dir(out)
        val args = mutableListOf("cargo", "ndk", "--platform", "26")
        abis.forEach { args += listOf("-t", it) }
        args += listOf("-o", out.get().asFile.absolutePath, "build")
        if (release) args += "--release"
        commandLine(args)
    }

val cargoDebug = registerCargo("debug", release = false)
val cargoRelease = registerCargo("release", release = true)
tasks.matching { it.name == "mergeDebugJniLibFolders" }.configureEach { dependsOn(cargoDebug) }
tasks.matching { it.name == "mergeReleaseJniLibFolders" }.configureEach { dependsOn(cargoRelease) }

kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }

dependencies {
    api("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    api(libs.kotlinx.coroutines.android)
    api(libs.okhttp)
    implementation(libs.androidx.core.ktx)
    implementation("androidx.browser:browser:1.9.0")
}
