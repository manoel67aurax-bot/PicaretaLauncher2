# Métodos JNI e modelos serializáveis não podem ser renomeados pelo R8
-keep class app.picareta.core.PicaretaNative { native <methods>; }
-keepclassmembers @kotlinx.serialization.Serializable class app.picareta.** { *; }
