package app.picareta.core.bedrock

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/**
 * Bedrock é um app nativo separado (comprado na Play Store). O launcher NÃO roda nem baixa o Bedrock:
 * ele abre o app oficial e entrega .mcpack/.mcaddon/.mcworld pra ele importar.
 */
object BedrockBridge {
    const val PACKAGE = "com.mojang.minecraftpe"

    fun isInstalled(ctx: Context): Boolean =
        runCatching { ctx.packageManager.getPackageInfo(PACKAGE, 0) }.isSuccess

    fun launch(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(PACKAGE) ?: return false.also { openStore(ctx) }
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }

    fun openStore(ctx: Context) {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PACKAGE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(market) } catch (_: ActivityNotFoundException) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$PACKAGE")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Copia pro cache compartilhável e manda pro Bedrock importar (ele mesmo mostra "Importação iniciada"). */
    fun importPack(ctx: Context, file: File): Boolean {
        if (!isInstalled(ctx)) { openStore(ctx); return false }
        val dir = File(ctx.cacheDir, "picareta-share").apply { mkdirs() }
        val shared = File(dir, file.name).also { file.copyTo(it, overwrite = true) }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.picareta.files", shared)
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/octet-stream").setPackage(PACKAGE)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { ctx.startActivity(i) }.isSuccess
    }
}
