package app.picareta.core.net

/** Modelo unificado pra tela de downloads mostrar Modrinth e CurseForge do mesmo jeito. */
enum class ContentType(val label: String) {
    MOD("Mods"), MODPACK("Modpacks"), RESOURCE_PACK("Texturas"), SHADER("Shaders"), DATAPACK("Datapacks"), WORLD("Mundos")
}

enum class Source { MODRINTH, CURSEFORGE }

data class ContentItem(
    val source: Source,
    val id: String,
    val slug: String,
    val title: String,
    val author: String,
    val description: String,
    val iconUrl: String?,
    val downloads: Long,
    val type: ContentType,
)

data class ContentFile(
    val fileName: String,
    val url: String?,          // null = autor bloqueou download por terceiros (CurseForge): abrir no navegador
    val sha1: String?,
    val sizeBytes: Long,
    val gameVersions: List<String>,
    val loaders: List<String>,
    val websiteUrl: String?,
)

data class SearchQuery(
    val text: String = "",
    val type: ContentType = ContentType.MOD,
    val gameVersion: String? = null,
    val loader: String? = null,   // fabric, forge, neoforge, quilt
    val page: Int = 0,
    val pageSize: Int = 20,
)

interface ContentSource {
    suspend fun search(q: SearchQuery): List<ContentItem>
    suspend fun files(item: ContentItem, gameVersion: String?, loader: String?): List<ContentFile>
}
