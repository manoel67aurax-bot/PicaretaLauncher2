package app.picareta.core

import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.boolean
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.Serializable

/** Ponte JNI com o núcleo Rust (libpicareta_core.so). Tudo chega como JSON {ok, value|error}. */
object PicaretaNative {
    init { System.loadLibrary("picareta_core") }

    @JvmStatic external fun offlineUuid(name: String): String
    @JvmStatic external fun checkSkin(path: String): String
    @JvmStatic external fun checkCape(path: String): String
    @JvmStatic external fun detectContent(path: String): String
    @JvmStatic external fun sha1(path: String): String
    @JvmStatic external fun exportBackup(requestJson: String): String
    @JvmStatic external fun importBackup(requestJson: String): String
}

val PicaretaJson = Json { ignoreUnknownKeys = true; explicitNulls = false; encodeDefaults = true }

class NativeException(message: String) : RuntimeException(message)

/** Converte a resposta do Rust em valor tipado ou lança [NativeException] com a mensagem amigável. */
inline fun <reified T> nativeCall(raw: String): T {
    val obj: JsonObject = PicaretaJson.parseToJsonElement(raw).jsonObject
    if (obj["ok"]?.jsonPrimitive?.boolean != true) {
        throw NativeException(obj["error"]?.jsonPrimitive?.contentOrNull ?: "Erro desconhecido")
    }
    return PicaretaJson.decodeFromJsonElement(obj["value"] as JsonElement)
}

@Serializable data class ImageCheck(val ok: Boolean, val width: Int, val height: Int, val kind: String, val message: String)

@Serializable data class Detection(val kind: String, val loader: String? = null, val root: String? = null)

@Serializable data class BackupMeta(val format: Int, val app: String, val files: List<String>)
