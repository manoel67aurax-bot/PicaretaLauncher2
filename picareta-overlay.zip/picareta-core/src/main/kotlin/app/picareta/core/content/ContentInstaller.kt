package app.picareta.core.content

import android.content.Context
import app.picareta.core.Detection
import app.picareta.core.NativeException
import app.picareta.core.PicaretaNative
import app.picareta.core.bedrock.BedrockBridge
import app.picareta.core.nativeCall
import app.picareta.core.net.ContentFile
import app.picareta.core.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.zip.ZipFile

/** Pra onde cada coisa vai dentro da instância (.minecraft isolado por perfil). */
sealed interface InstallResult {
    data class Installed(val file: File) : InstallResult
    data class SentToBedrock(val ok: Boolean) : InstallResult
    /** Modpacks vão pro instalador de modpack que o Zalith 2+ já tem. */
    data class NeedsModpackInstaller(val file: File, val format: String) : InstallResult
    data class NeedsWorldPick(val file: File) : InstallResult   // datapack: escolher em qual mundo
}

class ContentInstaller(private val ctx: Context, private val gameDir: File) {

    suspend fun download(f: ContentFile, onProgress: (Float) -> Unit = {}): File = withContext(Dispatchers.IO) {
        val url = f.url ?: throw IOException("Esse autor só libera download pelo site")
        val tmp = File(ctx.cacheDir, "dl/${f.fileName}.part").apply { parentFile?.mkdirs() }
        Http.ok.newCall(Request.Builder().url(url).build()).execute().use { res ->
            if (!res.isSuccessful) throw IOException("Download falhou (HTTP ${res.code})")
            val body = res.body ?: throw IOException("Resposta vazia")
            val total = body.contentLength().takeIf { it > 0 } ?: f.sizeBytes
            body.byteStream().use { input -> tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024); var done = 0L
                while (true) {
                    ensureActive()
                    val n = input.read(buf); if (n < 0) break
                    out.write(buf, 0, n); done += n
                    if (total > 0) onProgress(done.toFloat() / total)
                }
            } }
        }
        f.sha1?.let { expected ->
            val got: String = nativeCall(PicaretaNative.sha1(tmp.absolutePath))
            if (!got.equals(expected, true)) { tmp.delete(); throw IOException("Arquivo corrompido (SHA-1 não bate), tenta de novo") }
        }
        File(tmp.parentFile, f.fileName).also { tmp.renameTo(it) }
    }

    suspend fun install(file: File, worldName: String? = null): InstallResult = withContext(Dispatchers.IO) {
        val d: Detection = try { nativeCall(PicaretaNative.detectContent(file.absolutePath)) } catch (e: NativeException) {
            throw IOException("Não reconheci esse arquivo: ${e.message}")
        }
        when (d.kind) {
            "mod" -> InstallResult.Installed(move(file, "mods"))
            "resource_pack" -> InstallResult.Installed(move(file, "resourcepacks"))
            "shader_pack" -> InstallResult.Installed(move(file, "shaderpacks"))
            "world" -> InstallResult.Installed(unzipWorld(file, d.root.orEmpty()))
            "data_pack" -> worldName?.let { InstallResult.Installed(move(file, "saves/$it/datapacks")) } ?: InstallResult.NeedsWorldPick(file)
            "modrinth_modpack" -> InstallResult.NeedsModpackInstaller(file, "mrpack")
            "curseforge_modpack" -> InstallResult.NeedsModpackInstaller(file, "curseforge")
            "bedrock_pack", "bedrock_world" -> InstallResult.SentToBedrock(BedrockBridge.importPack(ctx, file))
            else -> throw IOException("Formato desconhecido")
        }
    }

    private fun move(src: File, sub: String): File {
        val dest = File(gameDir, "$sub/${src.name}").apply { parentFile?.mkdirs() }
        if (!src.renameTo(dest)) { src.copyTo(dest, overwrite = true); src.delete() }
        return dest
    }

    private fun unzipWorld(zip: File, root: String): File {
        val base = File(gameDir, "saves").apply { mkdirs() }
        var name = root.trimEnd('/').substringAfterLast('/').ifBlank { zip.nameWithoutExtension }
        var target = File(base, name); var n = 2
        while (target.exists()) { target = File(base, "$name ($n)"); n++ }
        val canonical = target.canonicalPath
        ZipFile(zip).use { z ->
            z.entries().asSequence().filter { !it.isDirectory && it.name.startsWith(root) }.forEach { e ->
                val out = File(target, e.name.removePrefix(root))
                require(out.canonicalPath.startsWith(canonical)) { "Zip malicioso" } // zip-slip
                out.parentFile?.mkdirs()
                z.getInputStream(e).use { i -> out.outputStream().use { i.copyTo(it) } }
            }
        }
        zip.delete()
        return target
    }
}
