package app.picareta.core.auth

import android.content.Context
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import app.picareta.core.PicaretaJson
import app.picareta.core.net.Http
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.UUID

/**
 * Ely.by (docs.ely.by/en/minecraft-auth.html): API compatível com Yggdrasil.
 * No launch, adicionar: -javaagent:<authlib-injector.jar>=ely.by  (skins Ely.by dentro do jogo)
 */
object ElyByAuth {
    private const val BASE = "https://authserver.ely.by/auth"
    const val REGISTER_URL = "https://account.ely.by/register"
    const val MS_SIGNUP_URL = "https://signup.live.com/"
    const val MC_BUY_URL = "https://www.minecraft.net/store/minecraft-java-bedrock-edition-pc"
    private val JSON = "application/json".toMediaType()

    class TwoFactorRequired : Exception("Essa conta usa 2FA: digite o código do app autenticador")
    class AuthError(msg: String) : Exception(msg)

    @Serializable private data class AuthReq(val username: String, val password: String, val clientToken: String, val requestUser: Boolean = true)
    @Serializable private data class RefreshReq(val accessToken: String, val clientToken: String, val requestUser: Boolean = true)
    @Serializable private data class Profile(val id: String, val name: String)
    @Serializable private data class AuthRes(val accessToken: String, val clientToken: String, val selectedProfile: Profile)
    @Serializable private data class ErrRes(val error: String = "", val errorMessage: String = "")

    private suspend inline fun <reified B> post(path: String, body: B): AuthRes = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$BASE/$path").post(PicaretaJson.encodeToString(body).toRequestBody(JSON)).build()
        Http.ok.newCall(req).execute().use { res ->
            val text = res.body?.string().orEmpty()
            if (res.isSuccessful) return@use PicaretaJson.decodeFromString(AuthRes.serializer(), text)
            val e = runCatching { PicaretaJson.decodeFromString(ErrRes.serializer(), text) }.getOrNull()
            if (e?.errorMessage?.contains("two factor", ignoreCase = true) == true) throw TwoFactorRequired()
            throw AuthError(e?.errorMessage?.ifBlank { null } ?: "Ely.by recusou o login (HTTP ${res.code})")
        }
    }

    /** Com 2FA, o Ely.by espera a senha no formato "senha:codigo". A senha nunca é salva. */
    suspend fun login(username: String, password: String, totp: String? = null): Account.ElyBy {
        val pass = if (totp.isNullOrBlank()) password else "$password:${totp.trim()}"
        val r = post("authenticate", AuthReq(username.trim(), pass, UUID.randomUUID().toString()))
        return Account.ElyBy(r.selectedProfile.name, r.selectedProfile.id, r.accessToken, r.clientToken)
    }

    suspend fun refresh(acc: Account.ElyBy): Account.ElyBy {
        val r = post("refresh", RefreshReq(acc.accessToken ?: throw AuthError("Faça login de novo"), acc.clientToken ?: ""))
        return acc.copy(accessToken = r.accessToken, clientToken = r.clientToken, name = r.selectedProfile.name)
    }

    fun skinUrl(name: String) = "https://skinsystem.ely.by/skins/$name.png"

    fun javaAgentArg(authlibInjectorJar: String) = "-javaagent:$authlibInjectorJar=ely.by"

    /** "Criar conta": abre o site oficial (nunca pedimos senha de cadastro dentro do app). */
    fun openInBrowser(context: Context, url: String) =
        CustomTabsIntent.Builder().setShowTitle(true).build().launchUrl(context, Uri.parse(url))
}
