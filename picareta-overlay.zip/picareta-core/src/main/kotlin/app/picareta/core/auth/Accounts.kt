package app.picareta.core.auth

import app.picareta.core.PicaretaNative
import app.picareta.core.nativeCall
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Modelo de conta do Picareta. Microsoft continua sendo feito pelo fluxo que o Zalith 2+ já tem
 * (OAuth -> Xbox Live -> XSTS -> Minecraft Services); aqui a gente só guarda o resultado.
 */
@Serializable
sealed class Account {
    abstract val name: String
    abstract val uuid: String
    abstract val skin: SkinRef?
    abstract val cape: String?          // caminho local da capa (sistema de capas do 2+)
    abstract val chroma: ChromaStyle?

    @Serializable @SerialName("offline")
    data class Offline(
        override val name: String, override val uuid: String,
        override val skin: SkinRef? = null, override val cape: String? = null, override val chroma: ChromaStyle? = null,
    ) : Account()

    @Serializable @SerialName("microsoft")
    data class Microsoft(
        override val name: String, override val uuid: String,
        val refreshToken: String? = null, val accessToken: String? = null, val expiresAt: Long = 0,
        override val skin: SkinRef? = null, override val cape: String? = null, override val chroma: ChromaStyle? = null,
    ) : Account()

    @Serializable @SerialName("elyby")
    data class ElyBy(
        override val name: String, override val uuid: String,
        val accessToken: String? = null, val clientToken: String? = null,
        override val skin: SkinRef? = null, override val cape: String? = null, override val chroma: ChromaStyle? = null,
    ) : Account()
}

@Serializable data class SkinRef(val path: String, val slim: Boolean = false)

/** Nome "chroma": gradiente animado no nome do jogador dentro do launcher. */
@Serializable data class ChromaStyle(val colors: List<Long> = listOf(0xFF7C4DFF, 0xFF00E5FF, 0xFF76FF03), val speedMs: Int = 2400)

object OfflineAccounts {
    private val NAME = Regex("^[A-Za-z0-9_]{3,16}$")

    fun validate(name: String): String? = when {
        name.length < 3 -> "Mínimo 3 caracteres"
        name.length > 16 -> "Máximo 16 caracteres"
        !NAME.matches(name) -> "Só letras, números e _"
        else -> null
    }

    /** UUID igual ao que o servidor vanilla gera em modo offline, então inventário/mundo batem. */
    fun create(name: String): Account.Offline =
        Account.Offline(name = name, uuid = nativeCall(PicaretaNative.offlineUuid(name)))
}
