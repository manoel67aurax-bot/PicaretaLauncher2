package app.picareta.core.net

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName
import java.net.URLEncoder

/** Modrinth API v2 (docs.modrinth.com). Limite: 300 req/min por IP, então o app faz debounce na busca. */
object ModrinthApi : ContentSource {
    private const val BASE = "https://api.modrinth.com/v2"

    private fun ContentType.facet() = when (this) {
        ContentType.MOD -> "mod"; ContentType.MODPACK -> "modpack"; ContentType.RESOURCE_PACK -> "resourcepack"
        ContentType.SHADER -> "shader"; ContentType.DATAPACK -> "datapack"; ContentType.WORLD -> "world"
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Facets: arrays externos = E, internos = OU. */
    fun facets(q: SearchQuery): String {
        val groups = mutableListOf(listOf("project_type:${q.type.facet()}"))
        q.gameVersion?.let { groups += listOf("versions:$it") }
        if (q.loader != null && q.type in setOf(ContentType.MOD, ContentType.MODPACK)) groups += listOf("categories:${q.loader}")
        return groups.joinToString(",", "[", "]") { g -> g.joinToString(",", "[", "]") { "\"$it\"" } }
    }

    @Serializable private data class SearchRes(val hits: List<Hit>)
    @Serializable private data class Hit(
        @SerialName("project_id") val id: String, val slug: String, val title: String, val author: String,
        val description: String, @SerialName("icon_url") val icon: String? = null, val downloads: Long = 0,
    )
    @Serializable private data class Version(
        val files: List<VFile>, @SerialName("game_versions") val gameVersions: List<String>, val loaders: List<String>,
    )
    @Serializable private data class VFile(val url: String, val filename: String, val primary: Boolean = false, val size: Long = 0, val hashes: Map<String, String> = emptyMap())

    override suspend fun search(q: SearchQuery): List<ContentItem> {
        val url = "$BASE/search?query=${enc(q.text)}&facets=${enc(facets(q))}&limit=${q.pageSize}&offset=${q.page * q.pageSize}&index=relevance"
        return Http.getJson<SearchRes>(url).hits.map {
            ContentItem(Source.MODRINTH, it.id, it.slug, it.title, it.author, it.description, it.icon, it.downloads, q.type)
        }
    }

    override suspend fun files(item: ContentItem, gameVersion: String?, loader: String?): List<ContentFile> {
        val params = buildList {
            if (loader != null && item.type == ContentType.MOD) add("loaders=${enc("[\"$loader\"]")}")
            if (gameVersion != null) add("game_versions=${enc("[\"$gameVersion\"]")}")
        }.joinToString("&")
        return Http.getJson<List<Version>>("$BASE/project/${item.id}/version?$params").mapNotNull { v ->
            val f = v.files.firstOrNull { it.primary } ?: v.files.firstOrNull() ?: return@mapNotNull null
            ContentFile(f.filename, f.url, f.hashes["sha1"], f.size, v.gameVersions, v.loaders, "https://modrinth.com/project/${item.slug}")
        }
    }
}
