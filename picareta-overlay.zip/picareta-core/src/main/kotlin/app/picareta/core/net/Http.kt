package app.picareta.core.net

import app.picareta.core.BuildConfig
import app.picareta.core.PicaretaJson
import kotlinx.coroutines.Dispatchers
import kotlinx.serialization.decodeFromString
import kotlinx.coroutines.withContext
import okhttp3.Cache
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Um único OkHttpClient pro app inteiro (pool de conexões + cache em disco de 20 MB). */
object Http {
    @Volatile private var client: OkHttpClient? = null

    fun init(cacheDir: File) {
        if (client != null) return
        client = OkHttpClient.Builder()
            .cache(Cache(File(cacheDir, "picareta-http"), 20L * 1024 * 1024))
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .addInterceptor { chain ->
                // Modrinth exige User-Agent único; mandamos pra todo mundo.
                chain.proceed(chain.request().newBuilder().header("User-Agent", BuildConfig.USER_AGENT).build())
            }
            .build()
    }

    val ok: OkHttpClient get() = client ?: error("Chame Http.init(context.cacheDir) no Application.onCreate")

    suspend inline fun <reified T> getJson(url: String, headers: Map<String, String> = emptyMap()): T =
        withContext(Dispatchers.IO) {
            val req = Request.Builder().url(url).apply { headers.forEach { (k, v) -> header(k, v) } }.build()
            ok.newCall(req).execute().use { res ->
                if (res.code == 429) throw IOException("Muitas buscas seguidas, espera uns segundos")
                if (!res.isSuccessful) throw IOException("HTTP ${res.code} em ${req.url.host}")
                PicaretaJson.decodeFromString<T>(res.body!!.string())
            }
        }
}
