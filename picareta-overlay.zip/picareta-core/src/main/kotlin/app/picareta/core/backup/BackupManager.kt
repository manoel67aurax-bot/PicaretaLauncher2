package app.picareta.core.backup

import app.picareta.core.BackupMeta
import app.picareta.core.PicaretaJson
import app.picareta.core.PicaretaNative
import app.picareta.core.auth.Account
import app.picareta.core.nativeCall
import app.picareta.core.settings.PicaretaSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.add
import java.io.File

/** Exporta/importa config + contas + skins + capas + chroma. Tokens são removidos no Rust. */
object BackupManager {
    data class Imported(val settings: PicaretaSettings, val accounts: List<Account>)

    suspend fun export(dest: File, settings: PicaretaSettings, accounts: List<Account>): BackupMeta = withContext(Dispatchers.IO) {
        val files = buildJsonArray {
            accounts.forEach { a ->
                a.skin?.path?.let { p -> add(buildJsonObject { put("path", p); put("name", "skins/${a.uuid}.png") }) }
                a.cape?.let { p -> add(buildJsonObject { put("path", p); put("name", "capes/${a.uuid}.png") }) }
            }
        }
        val req = buildJsonObject {
            put("dest", dest.absolutePath)
            put("settings_json", PicaretaJson.encodeToString(PicaretaSettings.serializer(), settings))
            put("accounts_json", PicaretaJson.encodeToString(ListSerializer(Account.serializer()), accounts))
            put("files", files)
        }
        nativeCall(PicaretaNative.exportBackup(req.toString()))
    }

    /** Extrai em [workDir] e devolve os dados já apontando pros arquivos de skin/capa extraídos. */
    suspend fun import(zip: File, workDir: File): Imported = withContext(Dispatchers.IO) {
        val req = buildJsonObject { put("zip", zip.absolutePath); put("dest", workDir.absolutePath) }
        nativeCall<BackupMeta>(PicaretaNative.importBackup(req.toString()))
        val settings = PicaretaJson.decodeFromString(PicaretaSettings.serializer(), File(workDir, "settings.json").readText())
        val accounts = PicaretaJson.decodeFromString(ListSerializer(Account.serializer()), File(workDir, "accounts.json").readText()).map { a ->
            val skin = File(workDir, "skins/${a.uuid}.png").takeIf { it.exists() }?.let { a.skin?.copy(path = it.absolutePath) }
            val cape = File(workDir, "capes/${a.uuid}.png").takeIf { it.exists() }?.absolutePath
            when (a) {
                is Account.Offline -> a.copy(skin = skin, cape = cape)
                is Account.Microsoft -> a.copy(skin = skin, cape = cape)   // sem token: pede login de novo
                is Account.ElyBy -> a.copy(skin = skin, cape = cape)
            }
        }
        Imported(settings, accounts)
    }
}
