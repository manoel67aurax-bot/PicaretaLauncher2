package app.picareta.core.settings

import android.app.ActivityManager
import android.content.Context
import app.picareta.core.PicaretaJson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable

@Serializable enum class Renderer(val label: String, val hint: String) {
    MOBILEGLUES("MobileGlues", "Melhor pra 1.17+ e shaders (GL 4.x via GLES 3.2)"),
    ZINK("Zink (Vulkan)", "Bom em Adreno/Mali recentes"),
    GL4ES("GL4ES", "Leve, ideal pra 1.16 e antigas"),
    ANGLE("ANGLE", "Alternativa estável em alguns Mali"),
}

@Serializable enum class ControlStyle(val label: String) { BEDROCK("Estilo Bedrock"), CLASSIC("Clássico Pojav"), GAMEPAD("Controle físico") }

@Serializable enum class Preset(val label: String) { BATTERY("Bateria"), BALANCED("Equilíbrio"), PERFORMANCE("Desempenho"), CUSTOM("Personalizado") }

@Serializable
data class PicaretaSettings(
    val preset: Preset = Preset.BALANCED,
    val ramMb: Int = 2048,
    val resolutionScale: Int = 75,         // % da resolução nativa
    val fpsLimit: Int = 60,
    val renderer: Renderer = Renderer.MOBILEGLUES,
    val controls: ControlStyle = ControlStyle.BEDROCK,
    val controlOpacity: Int = 70,
    val hapticFeedback: Boolean = true,
    val sustainedPerformance: Boolean = true,
    val gyroCamera: Boolean = false,
    val javaArgs: String = "-XX:+UseG1GC -XX:MaxGCPauseMillis=50",
    val chromaNames: Boolean = true,
    val homeShortcuts: Boolean = true,
) {
    fun applyPreset(p: Preset, deviceRamMb: Int): PicaretaSettings {
        val safeRam = (deviceRamMb * 0.45).toInt().coerceIn(1024, 6144) // nunca come a RAM toda do celular
        return when (p) {
            Preset.BATTERY -> copy(preset = p, ramMb = minOf(1536, safeRam), resolutionScale = 60, fpsLimit = 30, sustainedPerformance = false)
            Preset.BALANCED -> copy(preset = p, ramMb = minOf(2560, safeRam), resolutionScale = 75, fpsLimit = 60, sustainedPerformance = true)
            Preset.PERFORMANCE -> copy(preset = p, ramMb = safeRam, resolutionScale = 100, fpsLimit = 120, sustainedPerformance = true)
            Preset.CUSTOM -> copy(preset = p)
        }
    }
}

/** Guarda em SharedPreferences como JSON; StateFlow pra UI Compose reagir. */
class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("picareta_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<PicaretaSettings> = _state.asStateFlow()

    val deviceRamMb: Int = (context.getSystemService(ActivityManager::class.java)?.let { am ->
        ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }.totalMem / (1024 * 1024)
    } ?: 4096L).toInt()

    private fun load(): PicaretaSettings = prefs.getString("json", null)
        ?.let { runCatching { PicaretaJson.decodeFromString(PicaretaSettings.serializer(), it) }.getOrNull() }
        ?: PicaretaSettings()

    fun update(transform: (PicaretaSettings) -> PicaretaSettings) {
        val next = transform(_state.value)
        _state.value = next
        prefs.edit().putString("json", PicaretaJson.encodeToString(PicaretaSettings.serializer(), next)).apply()
    }
}
