package app.picareta.core.net

import app.picareta.core.BuildConfig
import kotlinx.serialization.Serializable
import java.io.IOException
import java.net.URLEncoder

/**
 * CurseForge for Studios API v1. Precisa de chave (console.curseforge.com) em CURSEFORGE_API_KEY.
 * gameId 432 = Minecraft. Página máx 50, índice + pageSize <= 10.000.
 */
object CurseForgeApi : ContentSource {
    private const val BASE = "https://api.curseforge.com/v1"
    private const val MINECRAFT = 432

    val enabled get() = BuildConfig.CURSEFORGE_API_KEY.isNotBlank()

    private fun ContentType.classId() = when (this) {
        ContentType.MOD -> 6; ContentType.MODPACK -> 4471; ContentType.RESOURCE_PACK -> 12
        ContentType.SHADER -> 6552; ContentType.DATAPACK -> 6945; ContentType.WORLD -> 17
    }
    private fun loaderType(l: String?) = when (l) { "forge" -> 1; "fabric" -> 4; "quilt" -> 5; "neoforge" -> 6; else -> null }
    private val headers get() = mapOf("x-api-key" to BuildConfig.CURSEFORGE_API_KEY, "Accept" to "application/json")

    @Serializable private data class Page<T>(val data: List<T>)
    @Serializable private data class Mod(
        val id: Long, val slug: String, val name: String, val summary: String, val downloadCount: Double = 0.0,
        val authors: List<Author> = emptyList(), val logo: Logo? = null, val links: Links? = null,
    )
    @Serializable private data class Author(val name: String)
    @Serializable private data class Logo(val thumbnailUrl: String? = null)
    @Serializable private data class Links(val websiteUrl: String? = null)
    @Serializable private data class File(
        val fileName: String, val downloadUrl: String? = null, val fileLength: Long = 0,
        val gameVersions: List<String> = emptyList(), val hashes: List<Hash> = emptyList(),
    )
    @Serializable private data class Hash(val value: String, val algo: Int) // algo 1 = SHA1

    override suspend fun search(q: SearchQuery): List<ContentItem> {
        if (!enabled) throw IOException("CurseForge desativado: falta a API key no build")
        val size = q.pageSize.coerceAtMost(50)
        val url = buildString {
            append("$BASE/mods/search?gameId=$MINECRAFT&classId=${q.type.classId()}&pageSize=$size&index=${q.page * size}")
            append("&sortField=2&sortOrder=desc") // 2 = popularidade
            if (q.text.isNotBlank()) append("&searchFilter=${URLEncoder.encode(q.text, "UTF-8")}")
            q.gameVersion?.let { append("&gameVersion=$it") }
            if (q.type == ContentType.MOD) loaderType(q.loader)?.let { append("&modLoaderType=$it") }
        }
        return Http.getJson<Page<Mod>>(url, headers).data.map {
            ContentItem(Source.CURSEFORGE, it.id.toString(), it.slug, it.name, it.authors.firstOrNull()?.name ?: "?",
                it.summary, it.logo?.thumbnailUrl, it.downloadCount.toLong(), q.type)
        }
    }

    override suspend fun files(item: ContentItem, gameVersion: String?, loader: String?): List<ContentFile> {
        val url = buildString {
            append("$BASE/mods/${item.id}/files?pageSize=50")
            gameVersion?.let { append("&gameVersion=$it") }
            if (item.type == ContentType.MOD) loaderType(loader)?.let { append("&modLoaderType=$it") }
        }
        val site = "https://www.curseforge.com/minecraft/${item.slug}"
        return Http.getJson<Page<File>>(url, headers).data.map { f ->
            ContentFile(
                f.fileName, f.downloadUrl, f.hashes.firstOrNull { it.algo == 1 }?.value, f.fileLength,
                f.gameVersions.filter { it.first().isDigit() },
                f.gameVersions.map { it.lowercase() }.filter { it in setOf("forge", "fabric", "quilt", "neoforge") },
                site,
            )
        }
    }
}
